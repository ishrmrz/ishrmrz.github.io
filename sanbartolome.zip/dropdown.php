<div class="row">
    <div class="col">

        <div class="input-group btn-group dropup form-control">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-location-dot"></i></span>
            </div>
            <select class="StartPoint">
                <option value="" disabled selected hidden>Select your location</option>
                <option>MAIN ENTRANCE</option>
                <option>BACK ENTRANCE</option> 
                <option>CHURCH FRONT ENTRANCE</option>
                <option>CHURCH SIDE ENTRANCE 1</option>
                <option>CHURCH SIDE ENTRANCE 2</option>
                <option>CEMETERY ENTRANCE</option>
                <option>CEMETERY</option>
                <option>COLUMBARY</option> 
                <option>OFFICE</option>
                <option>PARKING</option>
                <option>STAGE</option>
                <option>FOUNTAIN</option>
                
            </select>
        </div>

    </div>

    <div class="col ">

        <div class="input-group btn-group dropup form-control">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-location-dot"></i></span>
            </div>
            <select class="EndPoint">
                <option value="" disabled selected hidden>Select your destination</option>
                <option>MAIN ENTRANCE</option>
                <option>BACK ENTRANCE</option> 
                <option>CHURCH FRONT ENTRANCE</option>
                <option>CHURCH SIDE ENTRANCE 1</option>
                <option>CHURCH SIDE ENTRANCE 2</option>
                <option>CEMETERY ENTRANCE</option>
                <option>CEMETERY</option>
                <option>COLUMBARY</option> 
                <option>OFFICE</option>
                <option>PARKING</option>
                <option>STAGE</option>
                <option>FOUNTAIN</option>

            </select>
        </div>

    </div>
     <button class="btn btn-primary" onclick="getSelectedOption()">CONFIRM LOCATION</button>
     <P></P><button class="btn btn-primary" onclick="toDash()">GO TO DASHBOARD</button>

</div>