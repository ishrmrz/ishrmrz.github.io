# BounceMarker for Leaflet

This little plugin for [Leaflet](https://www.leafletjs.com) will make a Marker
bounce when you add it on a map on whenever you want it to.

Watch the [demo](http://maximeh.github.io/leaflet.bouncemarker/).

# Version

Things may break in master, so please don't use this in production.
[Tags](https://github.com/maximeh/leaflet.bouncemarker/tags) should be preferred for used in production.

Last stable: [v1.2.3](https://github.com/maximeh/leaflet.bouncemarker/releases/tag/v1.2.3)

# Documentation

