<?php include 'head.php';?>
<body class="bg-dark">

<div id="main">
    <div class="container">
      <div id="map">
      </div>
    </div>
    
  </div>
<footer>
    <div class="fixed-bottom">
        <div class="container p-5">
        <?php include 'dropdown.php';?>
        </div>

    </div>
</footer>


</body>
<?php include 'scripts.php';?>

</html>